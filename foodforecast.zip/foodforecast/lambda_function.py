import urllib3
import simplejson as json
import boto3
import random
from boto3.dynamodb.conditions import Key, Attr
from botocore.exceptions import ClientError
abc="   "

def lambda_handler(event, context):
    """if (event["session"]["application"]["applicationId"] !=
            ""):
        raise ValueError("Invalid Application ID")
    """
    if event["session"]["new"]:
        on_session_started({"requestId": event["request"]["requestId"]}, event["session"])

    if event["request"]["type"] == "LaunchRequest":
        return on_launch(event["request"], event["session"])
    elif event["request"]["type"] == "IntentRequest":
        return on_intent(event["request"], event["session"])
        """return on_intent(event,event["session"])"""
    elif event["request"]["type"] == "SessionEndedRequest":
        print("bcd")
        return on_session_ended(event["request"], event["session"])

def on_session_started(session_started_request, session):
    print ("Starting new session.")

def on_launch(launch_request, session):
    print ("Launch")
    return get_welcome_response()

def on_intent(intent_request, session):
    intent = intent_request["intent"]
    print(intent)
    intent_name = intent_request["intent"]["name"]
    """intent=event["request"]["intent"]
    intent_name=event["request"]["intent"]["name"]
    slots=event["request"]["intent"]["name"]["slots"]"""
    
    if intent_name == "AMAZON.YesIntent":
        return get_yes_response()
    elif intent_name == "AMAZON.CancelIntent" or intent_name == "AMAZON.StopIntent":
        print("aa")
        return handle_session_end_request()
    elif intent_name=="LocationIntent":
        """slots1=intent['slots']
        slots=slots1['places']['value']
        if intent['slots']['places']['value'] is not None:
            slots1=intent['slots']
            slots=slots1['places']['value']
            return get_location(slots)
        else:"""
        if 'places' in intent['slots']:
            if 'value' in intent['slots']['places']:
                slots1=intent['slots']
                slots=slots1['places']['value']
                return get_location(slots)
            else:
                return err()
        else:    
            return err()
        
    elif intent_name=="ThankIntent":
        if 'thank' in intent['slots']:
            if 'value' in intent['slots']['thank']:
                slots2=intent['slots']
                slots3=slots2['thank']['value']
                print(slots3)
                if slots3=="Thank you" or slots3=="Thanks" or slots3=="Thank you very much" or slots3=="no thanks":
                    print("d")
                    return handle_session_end_request()
                else:
                    print("e")
                    return err()
            else:
                print("f")
                return err()
        else:
            print("f")
            return err()    
    elif intent_name=="AMAZON.HelpIntent":
        return handle_help()
    else:
        raise ValueError("Invalid intent")



def handle_help():
    card_title = "Food forecast"
    speech_output = "Food Forecast interprets the city's current weather and accordingly suggests users with delicious dishes, along with various places to try them at. So can you please enter a location?"
    should_end_session = False

    return build_response({}, build_speechlet_response(card_title, speech_output, None, should_end_session))

        
def on_session_ended(session_ended_request, session):
    print ("Ending session.")
    
    
def err():
    card_title = "Food forecast"
    speech_output = "Invalid input enter again "
    should_end_session = False

    return build_response({}, build_speechlet_response(card_title, speech_output, None, should_end_session))
    
def handle_session_end_request():
    card_title = "Food forecast"
    speech_output = "Thank you for using food forecast, bon appetit"
    should_end_session = True

    return build_response({}, build_speechlet_response(card_title, speech_output, None, should_end_session))


def get_welcome_response():
    print ("get_welcome_response")
    session_attributes={}
    card_title = "Food Forecast"
    
    speech_output = "Hey foodie, do you want to know about today's food weather, can I please know your city for that?"  		
    reprompt_text = "Can I please know your location" 
    should_end_session = False
    return build_response(session_attributes, build_speechlet_response(
    card_title, speech_output, reprompt_text, should_end_session))




def get_location(slots):

    if slots=="ahmedabad" or slots=="Ahmedabad" or slots=="Delhi" or slots=="delhi":

        if slots=="ahmedabad" or slots=="Ahmedabad":
            API_BASE="http://api.openweathermap.org/data/2.5/weather?id=1266809&appid=4304cf0246f22d3e0919a4d2f1907e43"
        else:
            API_BASE="http://api.openweathermap.org/data/2.5/weather?id=1273293&appid=4304cf0246f22d3e0919a4d2f1907e43"

        http = urllib3.PoolManager()
        response = http.request('GET',API_BASE)
        dictionary=json.loads(response.data)
        print("",dictionary["main"]["temp"])
        
        out=""
        temp=int(dictionary["main"]["temp"])
        temp=temp-273
        if temp>=30:
            weather="Summer"
            out="Look's like it's hot out there in "
            print(weather)    
        if temp<=20:
            weather="Winter"
            out="The weather is quite chilly in "
            print(weather)    
        if temp>=21 and temp<=29:
            weather="Monsoon"
            out="The sky seems to be cloudy in "
            print(weather)
            
           
        print(out)    
        slots=slots[0].lower() + slots[1:]
        
        dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
        table = dynamodb.Table('location')
        try:
            
            response=table.update_item(
            Key={
                'PK': 1
            },
            UpdateExpression="set Place = :p, Weather = :w",
            ExpressionAttributeValues={
            
                ':p': slots,
                ':w': weather
            
            },
            ReturnValues="UPDATED_NEW"
            )
            
        except ClientError as e:
            if e.response['Error']['Code'] == 'ValidationException':
            
            
                response = table.update_item(
                  Key={
                      'PK': 1
                  
                  },
                  UpdateExpression="set #attrName = :attrValue",
                  ExpressionAttributeNames = {
                      "#attrName" : "info"
                  },
                  ExpressionAttributeValues={
                      ':attrValue': {
                          'Place': slots,
                          'Weather': weather
                      }
                  },
                  ReturnValues="UPDATED_NEW"
                )
            else:
                raise
            
        session_attributes={}
        card_title = "Food Forecast"
        
        speech_output = out+", "+slots+", do you need some tasty suggestion to try in this weather? "  		
        reprompt_text = "Do you need any food suggestion ?" 
        should_end_session = False
        return build_response(session_attributes, build_speechlet_response(
        card_title, speech_output, reprompt_text, should_end_session))

    else:
        return err()



def get_yes_response():


    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    table = dynamodb.Table('location')
    response = table.query(
    KeyConditionExpression=Key('PK').eq(1))
    print(response['Items'][0]['Place'])
    slots=response['Items'][0]['Place']
    weath=response['Items'][0]['Weather']
    print(weath)

    
    session_attributes={}
    card_title = "Food Forecast"
    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    table = dynamodb.Table(slots)
    response = table.query(
    KeyConditionExpression=Key('Season').eq(weath))
    print(response)
    if slots=='ahmedabad':
        n=random.randint(1,8)
    else:
        n=random.randint(1,4)

    
    """print(response['Items']['Food2'])
    for i in response['Items']:
        print (i)"""

    f="Food"+str(n)
    p1="F"+str(n)+"P1"
    p2="F"+str(n)+"P2"
    print( f ," ",p1," ",p2)
    print(response['Items'][0][f]+"aaa"+response['Items'][0][p1]+"bb"+response['Items'][0][p2])
    sample=['This dish is absolutely delicious.','It is a hit in your city.','You should not miss out on this.']	
    ss=random.randint(0,2)	
    speech_output = "You can try "+response['Items'][0][f]+", at "+response['Items'][0][p1]+", or at "+response['Items'][0][p2]+". "+sample[ss]+", have you already tried this? Do you want another suggestion?" 	
    reprompt_text = "Want another suggestion ?"
    should_end_session = False
    return build_response(session_attributes, build_speechlet_response(
    card_title, speech_output, reprompt_text, should_end_session))




def build_speechlet_response(title, output, reprompt_text, should_end_session):
    return {
        "outputSpeech": {
            "type": "SSML",
            "ssml": "<speak>"+output+"</speak>"
        },
        "card": {
            "type": "Simple",
            "title": title,
            "content": output
        },
        "reprompt": {
            "outputSpeech": {
                "type": "PlainText",
                "text": reprompt_text
            }
        },
        "shouldEndSession": should_end_session
    }

def build_response(session_attributes, speechlet_response):
    return {
        "version": "1.0",
        "sessionAttributes": session_attributes,
        "response": speechlet_response
    }	

