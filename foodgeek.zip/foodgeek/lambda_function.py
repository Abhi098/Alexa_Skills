import urllib3
import simplejson as json
import boto3
import random
from boto3.dynamodb.conditions import Key, Attr
from botocore.exceptions import ClientError

def lambda_handler(event, context):
    """if (event["session"]["application"]["applicationId"] !=
            ""):
        raise ValueError("Invalid Application ID")
    """
    if event["session"]["new"]:
        on_session_started({"requestId": event["request"]["requestId"]}, event["session"])

    if event["request"]["type"] == "LaunchRequest":
        return on_launch(event["request"], event["session"])
    elif event["request"]["type"] == "IntentRequest":
        return on_intent(event["request"], event["session"])
        """return on_intent(event,event["session"])"""
    elif event["request"]["type"] == "SessionEndedRequest":
        return on_session_ended(event["request"], event["session"])

def on_session_started(session_started_request, session):
    print ("Starting new session.")

def on_launch(launch_request, session):
    print ("Launch")
    return get_welcome_response()

def on_intent(intent_request, session):
    intent = intent_request["intent"]
    intent_name = intent_request["intent"]["name"]
    """intent=event["request"]["intent"]
    intent_name=event["request"]["intent"]["name"]
    slots=event["request"]["intent"]["name"]["slots"]"""
    
    if intent_name == "AMAZON.YesIntent" or intent_name== "AMAZON.NoIntent":
        return get_yes_response()
    elif intent_name == "AMAZON.CancelIntent" or intent_name == "AMAZON.StopIntent":
        return handle_session_end_request()
    elif intent_name=="GameIntent":
        slots1=intent['slots']
        slots=slots1['Game']['value']
        print("a",slots)   
        return get_sports(slots)
    elif intent_name=="ThankIntent":
        return handle_session_end_request()
    elif intent_name=="AMAZON.HelpIntent":
        return handle_help()
    else:
        raise ValueError("Invalid intent")

def on_session_ended(session_ended_request, session):
    print ("Ending session.")
    
def handle_help():
    card_title = "Food geek"
    speech_output = "Food Geek is an Alexa skill set intended to help all the sports enthusiasts with their diet. It offers a five course meal with different dishes for each sport at valid time of the day or else it would just ask you to ask again later. So please enter your sport "
    should_end_session = False
    return build_response({}, build_speechlet_response(card_title, speech_output, None, should_end_session))
    
def get_yes_response():
    card_title = "Food geek"
    speech_output = "Please enter valid input "
    should_end_session = False
    return build_response({}, build_speechlet_response(card_title, speech_output, None, should_end_session))
    
def handle_session_end_request():
    card_title = "Food geek"
    speech_output = "Thank you for using food geek, bon appetit "
    should_end_session = True

    return build_response({}, build_speechlet_response(card_title, speech_output, None, should_end_session))


def get_welcome_response():
    print ("get_welcome_response")
    session_attributes={}
    card_title = "Food geek"
    
    speech_output = "Hey, I know how essential a diet is for you, so  I am here to help you, the categories are Cricket,Badminton,Football and swimming. Please enter your sport"  		
    reprompt_text = "can I please know your sport" 
    should_end_session = False
    return build_response(session_attributes, build_speechlet_response(
    card_title, speech_output, reprompt_text, should_end_session))




def get_sports(slots):

    name=""
    if slots!=None or slots=='Cricket' or slots=='Football' or slots=='Badminton' or slots=='Swimming': 
        if slots=='Cricket':
            name='Cricketer'

        if slots=='Football':
            name='Footbaler'

        if slots=='Badminton':
            name='Shutler'

        if slots=='Swimming':
            name='Swimmer'

                
        print(name)
        api="http://api.timezonedb.com/v2/get-time-zone?key=RG5R8ZRPBQ01&format=json&by=zone&zone=Asia/Kolkata&fields=formatted"

        game=slots.title()
        http = urllib3.PoolManager()
        response = http.request('GET',api)
        dictionary=json.loads(response.data)
        a,b=dictionary['formatted'].split(" ")
        print(a)
        print(b)
        a,b,c=b.split(":")
        print(a)
        a=int(a)
        print(slots)
        dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
        table = dynamodb.Table('Fitness')
        response = table.query(
        KeyConditionExpression=Key('Game').eq(game))
        print(response)
        """print(response['Items'][0]['B1'])"""
        if a>=7 and a<=9:
            out="Hey "+name+" its time for a healthy breakfast which can include, "+response['Items'][0]['B1']+", or you can have, "+response['Items'][0]['B2']+"."
            
        if a>=10 and a<=12:
            out="Hey "+name+" its time for your mid day snack to keey energetic  which can include, "+response['Items'][0]['MDS1']+", or you can have, "+response['Items'][0]['MDS2']+"."
            
        if a>=13 and a<=15:
            out="Hey "+name+" its a long day ahead why don't you get some lunch which can include, "+response['Items'][0]['L1']+", or you can have, "+response['Items'][0]['L2']+"."

        if a>=16 and a<=18:
            out="Hey "+name+" its time for a healthy evening snack which can include, "+response['Items'][0]['ES1']+", or you can have, "+response['Items'][0]['ES2']+"."

        if a>=19 and a<=23:
            out="Hey "+name+", its time for the final meal of your day. You can have, "+response['Items'][0]['B1']+" or you can have, "+response['Items'][0]['B2']+", and then get a good night sleep."

        else:
            out="Hey"+name+", it is not a good time to have a meal now, please wait for some hours and ask again Thank you so much."
            session_attributes={}
            card_title = "Sports Geek"
        
            speech_output = out  		
            reprompt_text = out 
            should_end_session = True
            return build_response(session_attributes, build_speechlet_response(
            card_title, speech_output, reprompt_text, should_end_session))

        print(out)    

        session_attributes={}
        card_title = "Sports Geek"
        
        speech_output = out  		
        reprompt_text = out 
        should_end_session = False
        return build_response(session_attributes, build_speechlet_response(
        card_title, speech_output, reprompt_text, should_end_session))

    else:
        session_attributes={}
        card_title = "Sports Geek"
        
        speech_output = "Please enter valid game like Cricket, football, badminton or swimming"  		
        reprompt_text = "Please enter valid game like Cricket, football, badminton or swimming"  		 
        should_end_session = False
        return build_response(session_attributes, build_speechlet_response(
        card_title, speech_output, reprompt_text, should_end_session))
        
            







def build_speechlet_response(title, output, reprompt_text, should_end_session):
    return {
        "outputSpeech": {
            "type": "SSML",
            "ssml": "<speak>"+output+"</speak>"
        },
        "card": {
            "type": "Simple",
            "title": title,
            "content": output
        },
        "reprompt": {
            "outputSpeech": {
                "type": "PlainText",
                "text": reprompt_text
            }
        },
        "shouldEndSession": should_end_session
    }

def build_response(session_attributes, speechlet_response):
    return {
        "version": "1.0",
        "sessionAttributes": session_attributes,
        "response": speechlet_response
    }	

